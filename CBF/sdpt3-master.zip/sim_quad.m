% System dimensions for the quadrotor
n = 10;  % State dimension (x)
m = 3;   % Input dimension (u)

% Parameters from the quadrotor model
g = 9.8; d0 = 10; d1 = 8; n0 = 10; kT = 0.91;

% System matrices for the continuous-time quadrotor dynamics (linearized approximation)
A = zeros(n, n);  % State matrix A
B = zeros(n, m);  % Input matrix B
A1 = zeros(n, n);
A2 = zeros(n, n);

% Defining the dynamics (replace with exact dynamics from quadrotor)
A(1,4) = 1; % x1_dot = v1
A(2,5) = 1; % x2_dot = v2
A(3,6) = 1; % x3_dot = v3
A(7,7) = -d1; A(7,8) = 1;  % v3_dot = -g + kT*u3
A(8,7) = -d0;    % phi1_dot = -d1*phi1 + omega1
A(9,9) = -d1; A(9,10) = 1;  % phi2_dot = -d1*phi2 + omega2
A(10,9) = -d0;               % omega1_dot = -d0*omega1 + n0*u1

A1(4,7) = g;  % g*tan(phi1) term
A2(5,7) = g;  % g*tan(phi2) term

% Input matrix B
B(8,1) = n0;   % omega1 affected by u1
B(10,2) = n0;  % omega2 affected by u2
B(6,3) = kT;   % v3 affected by u3 (thrust)

% Decision variables
X = sdpvar(n, n, 'symmetric');  % Lyapunov matrix X
Y = sdpvar(m, n, 'full');       % Controller gain Y
X1 = sdpvar(n, n, 'symmetric');  % Lyapunov matrix X
X2 = sdpvar(n, n, 'symmetric');  % Lyapunov matrix X


% Parameters for the LMI constraints
rho_c = 0.192;
lambda = 0.1084;

% Disturbance matrix E
E = zeros(n, m);  
E(1,1) = 1;   % omega1 disturbance 
E(2,2) = 1;   % omega2 disturbance
E(3,3) = 1;   % v3 disturbance

% Define the nonlinear parameter-dependent matrix A_theta
Theta1 = [0, 2.828];  % Theta range for nonlinear dynamics (using tan^2(pi/4))
Theta2 = [0, 2.828];

F = [];  % Initialize constraints

% LMI Constraints (loop over the vertices of the parameter set)
for i = 1:2
    for j = 1:2
        theta1_nl = Theta1(i);
        theta2_nl = Theta2(j);
        A_theta_nl = A + theta1_nl * A1 + theta2_nl * A2;  % System dynamics for each vertex
            
        Xr = X + theta1_nl *X1 + theta1_nl *X2;

        % First LMI: Stability condition
        LMI_stability = A_theta_nl * Xr + B * Y + (A_theta_nl * Xr + B * Y)' <= 0;
        F = [F, LMI_stability];

        % % Second LMI: Disturbance rejection
        % LMI_disturbance = [A_theta_nl * Xr + B * Y + (A_theta_nl * Xr + B * Y)' + lambda * Xr, E;
        %                    E', -lambda * eye(3)] <= 0;
        % F = [F, LMI_disturbance];
    end
end

% Objective: No specific objective
Objective = -logdet(X);

% Solver settings (use SDPT3 solver)
options = sdpsettings('solver', 'sdpt3', 'verbose', 1, 'sdpt3.maxit', 100);

% Solve the LMI problem
sol = optimize(F, Objective, options);

% Check and display results
if sol.problem == 0
    disp('Controller design successful:');
    X_opt = value(X);
    Y_opt = value(Y);
    disp('Optimal Lyapunov matrix X:');
    disp(X_opt);
    disp('Optimal controller gain Y:');
    disp(Y_opt);
    
    % Feedback gain
    K = Y_opt / X_opt;  % Controller gain
    
    % Simulation parameters
    T = 10;  % Total simulation time (seconds)
    dt = 0.01;  % Time step
    t = 0:dt:T;  % Time vector
    x = zeros(n, length(t));  % State trajectory (n x length of time)
    
    % Initial state (you can change this to another initial condition)
    x(:,1) = [1; 1; 1; 0; 0; 0; 0; 0; 0; 0];  % Initial state x0

    % Simulate the system using Euler integration
    for k = 1:length(t)-1
        % Compute control input u = K * x
        u = K * x(:,k);
        
        % Update the state using the discretized state-space model
        x_dot = (A) * x(:,k) + B * u;  % Compute the derivative dx/dt
        % x_dot = (A + A1*2.8*rand + A2*2.8*rand) * x(:,k) + B * u;  % Compute the derivative dx/dt
        x(:,k+1) = x(:,k) + dt * x_dot;  % Euler integration
    end
    
    % Plot the results
    figure;
    subplot(3,1,1);
    plot(t, x(1,:), 'LineWidth', 1.5);
    title('State x_1 over time');
    xlabel('Time (s)');
    ylabel('x_1');
    
    subplot(3,1,2);
    plot(t, x(2,:), 'LineWidth', 1.5);
    title('State x_2 over time');
    xlabel('Time (s)');
    ylabel('x_2');
    
    subplot(3,1,3);
    plot(t, x(3,:), 'LineWidth', 1.5);
    title('State x_3 over time');
    xlabel('Time (s)');
    ylabel('x_3');
    
else
    disp('Controller design failed.');
    sol.info
end
