% Define the transfer function G(s)
a = 2;
numerator = [a, a]; % Coefficients of the numerator (5s + 50)
denominator = [1, a]; % Coefficients of the denominator (s + 5)
G = tf(numerator, denominator);

% Plot the Bode magnitude response
figure;
bode(G);
grid on;
title('Bode Magnitude Response of G(s)');

% Compute the maximum magnitude (peak gain)
[max_gain, freq] = getPeakGain(G);

% Convert maximum gain to dB
max_gain_dB = 20 * log10(max_gain);

% Display the result
disp(['Maximum Magnitude (Linear): ', num2str(max_gain)]);
disp(['Maximum Magnitude (dB): ', num2str(max_gain_dB)]);

