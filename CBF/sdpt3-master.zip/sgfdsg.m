% Define the magnitude of G(jw) as a function handle
G_jw = @(w) (5 * sqrt(w.^2 + 1)) ./ sqrt(w.^2 + 25);

% Compute the integral numerically over [0, Inf)
L1_norm = (1 / pi) * integral(G_jw, 0, Inf);

% Display the result
disp(['L1 Norm (Frequency Domain): ', num2str(L1_norm)]);
