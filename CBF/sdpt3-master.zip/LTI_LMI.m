% Define system dimensions
n = 3;  % State dimension
m = 2;  % Input dimension

% System matrices (random example matrices, replace with your specific system)
A = [0.5, 0.2, 0.1;
     0.1, 0.4, 0.3;
     0.3, 0.2, 0.5];  % A is 3x3

B = [0.1, 0.2;
     0.2, 0.1;
     0.1, 0.3];       % B is 3x2

% Define decision variables
P = sdpvar(n, n, 'symmetric');  % Lyapunov matrix (positive definite)
Y = sdpvar(m, n, 'full');       % Control gain Y (where K = Y*P^(-1))

% LMI formulation
LMI = [];
LMI = [LMI, P >= 1e-6 * eye(n)];  % Ensure P is positive definite

% Construct the LMI for closed-loop stability
A_cl = A * P + B * Y;  % Closed-loop matrix A + BK
LMI = [LMI, A_cl' + A_cl <= -eye(n)];  % Lyapunov inequality (A_cl^T P + P A_cl < 0)

% Objective function (no specific objective in this case)
Objective = [];

% Solver settings (use SeDuMi)
options = sdpsettings('solver', 'sedumi', 'verbose', 1);

% Solve the LMI problem
sol = optimize(LMI, Objective, options);

% Check and display results
if sol.problem == 0
    disp('Feasible solution found!');
    P_opt = value(P);
    K_opt = value(Y) * inv(P_opt);  % Feedback gain K = Y * P^(-1)
    disp('Optimal P matrix:');
    disp(P_opt);
    disp('Optimal feedback gain K:');
    disp(K_opt);
    
    % Simulation parameters
    T = 10;  % Total simulation time in seconds
    dt = 0.01;  % Time step
    t = 0:dt:T;  % Time vector
    x = zeros(n, length(t));  % State trajectory (n x length of time)
    
    % Initial state (you can change this to another initial condition)
    x(:,1) = [1; 1; 1];  % Initial state x0
    
    % Simulate the system using Euler integration
    for k = 1:length(t)-1
        % Compute control input u = K * x
        u = K_opt * x(:,k);
        
        % Update the state using the discretized state-space model
        x_dot = A * x(:,k) + B * u;  % Compute the derivative dx/dt
        x(:,k+1) = x(:,k) + dt * x_dot;  % Euler integration
    end
    
    % Plot the results
    figure;
    subplot(3,1,1);
    plot(t, x(1,:), 'LineWidth', 1.5);
    title('State x_1 over time');
    xlabel('Time (s)');
    ylabel('x_1');
    
    subplot(3,1,2);
    plot(t, x(2,:), 'LineWidth', 1.5);
    title('State x_2 over time');
    xlabel('Time (s)');
    ylabel('x_2');
    
    subplot(3,1,3);
    plot(t, x(3,:), 'LineWidth', 1.5);
    title('State x_3 over time');
    xlabel('Time (s)');
    ylabel('x_3');
    
else
    disp('Problem not solved. Check feasibility.');
    sol.info
end
