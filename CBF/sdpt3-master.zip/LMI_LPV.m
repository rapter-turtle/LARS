% System dimensions for the quadrotor
n = 6;  % State dimension (x)
m = 3;   % Input dimension (u)

% System matrices for the continuous-time quadrotor dynamics (linearized approximation)
A = zeros(n, n);  % State matrix A
B = zeros(n, m);  % Input matrix B
A1 = zeros(n, n);
A2 = zeros(n, n);
A3 = zeros(n, n);

% Defining the dynamics (replace with exact dynamics from quadrotor)
A(1,4) = -1; % x1_dot = v1
A(2,5) = -1; % x2_dot = v2
A(3,6) = -1; % x3_dot = v3
A1(1,2) = 1;
A1(2,1) = -1;
A2(1,6) = 1;
A2(2,6) = -1;


% Input matrix B
B(4,1) = 1;
B(5,2) = 1;
B(6,3) = 1;

% Decision variables
X = sdpvar(n, n, 'symmetric');  % Lyapunov matrix X
Y = sdpvar(m, n, 'full');       % Controller gain Y

X1 = sdpvar(n, n, 'symmetric');
X2 = sdpvar(n, n, 'symmetric');
X3 = sdpvar(n, n, 'symmetric');

lau = sdpvar(1, 1, 'full'); 
lamda = sdpvar(1, 1, 'full'); 

% Parameters for the LMI constraints
% Disturbance matrix E
E = zeros(n, m);  
E(2,1) = 1;   % omega1 disturbance 



% Define the nonlinear parameter-dependent matrix A_theta
Theta1 = [-4, 4];  % Theta range for nonlinear dynamics (using tan^2(pi/4))
Theta2 = [-4, 4];
Theta3 = [-1, 1];

F = [];  % Initialize constraints

% LMI Constraints (loop over the vertices of the parameter set)
for i = 1:2
    for j = 1:2
        for k = 1:2
            theta1_nl = Theta1(i);
            theta2_nl = Theta2(j);
            theta3_nl = Theta3(k);
            A_theta_nl = A + theta1_nl * A1 + theta2_nl * A2 + theta3_nl * A3;  % System dynamics for each vertex
            Xr = X + theta1_nl * X1 + theta2_nl * X2 + theta3_nl * X3;
            % Xr = X;
            lamda = 0.23;
            lau = 0.5;
            % % First LMI: Stability condition
            LMI_stability = A_theta_nl * Xr + B * Y + (A_theta_nl * Xr + B * Y)' + 2*lau*Xr <= 0;
            F = [F, LMI_stability];

            disturbance_stability = [A_theta_nl * Xr + B * Y + (A_theta_nl * Xr + B * Y)' + lamda*Xr, B;
                B', -lamda*eye(3)] <=0;
            F = [F, disturbance_stability];

            % LMI_stability = A_theta_nl * Xr + B * Y + (A_theta_nl * Xr + B * Y)'<= 0;
            % F = [F, LMI_stability];
            % 
            % disturbance_stability = [A_theta_nl * Xr + B * Y + (A_theta_nl * Xr + B * Y)', B;
            %     B', -0.5*eye(3)] <=0;
            % F = [F, disturbance_stability];
        end
    end
end

Lx = [1,0,0,0,0,0];
Ly = [0,1,0,0,0,0];
Lr = [0,0,1,0,0,0];

F = [F, Lx*Xr <=2];
F = [F, Lx*Xr >=-2];

F = [F, Ly*Xr <=2];
F = [F, Ly*Xr >=-2];

F = [F, Lr*Xr <=1];
F = [F, Lr*Xr >=-1];

% F = [F, lau >=0];
% F = [F, lamda >=0];
% Objective: No specific objective
Objective = [];
% Objective = -log(det(Xr));
% Objective = -X;

% Solver settings (use SDPT3 solver)
options = sdpsettings('solver', 'sdpt3', 'verbose', 1, 'sdpt3.maxit', 300);

% Solve the LMI problem
sol = optimize(F, Objective, options);

% Check and display results
if sol.problem == 0
    disp('Controller design successful:');
    X_opt = value(X);
    Y_opt = value(Y);
    disp('Optimal Lyapunov matrix X:');
    disp(X_opt);
    disp('Optimal Lyapunov matrix X1:');
    disp(value(X1));
    disp('Optimal Lyapunov matrix X2:');
    disp(value(X2));
    disp('Optimal Lyapunov matrix X3:');
    disp(value(X3));
    disp('Optimal controller gain Y:');
    disp(Y_opt);
    % % Feedback gain

    % Simulation parameters
    T = 100;  % Total simulation time (seconds)
    dt = 0.01;  % Time step
    t = 0:dt:T;  % Time vector
    x = zeros(n, length(t));  % State trajectory (n x length of time)

    % Initial state (you can change this to another initial condition)
    x(:,1) = [0.4; 0.4; -0.2; 0; 0; 0];  % Initial state x0

    % Simulate the system using Euler integration
    for k = 1:length(t)-1
        % Compute control input u = K * x
        rm = 0;
        % Update the state using the discretized state-space model
        
        K = Y_opt / (X_opt + value(X1)*(x(:,6) + rm) + value(X2)*x(:,1) + value(X3)*x(:,2));  % Controller gain
        
        % disp(K);

        x_dot = (A + A1.*(x(:,6) + rm))*x(:,k) + A2.*(x(:,1))*x(:,k) + A3.*(x(:,2))*x(:,k) + B*K*x(:,k);
        x(:,k+1) = x(:,k) + dt * x_dot;  % Euler integration
    end

    % Plot the results
    figure;
    subplot(3,1,1);
    plot(t, x(1,:), 'LineWidth', 1.5);
    title('State x_1 over time');
    xlabel('Time (s)');
    ylabel('x_1');

    subplot(3,1,2);
    plot(t, x(2,:), 'LineWidth', 1.5);
    title('State x_2 over time');
    xlabel('Time (s)');
    ylabel('x_2');

    subplot(3,1,3);
    plot(t, x(3,:), 'LineWidth', 1.5);
    title('State x_3 over time');
    xlabel('Time (s)');
    ylabel('x_3');
    
else
    disp('Controller design failed.');
    sol.info
end
