% Randomly generated system matrices
A = [1,-1;-2,-4];   % Random 2x2 matrix for A
B = [0;1];   % Random 2x1 matrix for B

% Define YALMIP variables
X = sdpvar(2,2);  % Symmetric matrix variable for Lyapunov matrix
Q = -eye(2);       % Symmetric positive definite matrix (identity for simplicity)

% Define LMI for stability
% The stability condition: A^T * X + X * A + Q <= 0
Constraints = [X >= 1e-5 * eye(2)]; % Ensure X is positive definite
Constraints = [Constraints, A' * X + X * A + Q <= 0];

% Objective: No objective needed (feasibility problem)
Objective = [];

% Solver settings
options = sdpsettings('solver', 'sdpt3', 'verbose', 1); % Use 'sedumi' or 'sdpt3'

% Solve the problem
sol = optimize(Constraints, Objective, options);

% Check feasibility and display results
if sol.problem == 0
    % Retrieve and display results
    X_opt = value(X);
    disp('Feasible solution found:')
    disp('X = ')
    disp(X_opt)
else
    disp('The problem is infeasible or solver could not find a solution.')
end
