clear

% Given matrices and constants
A = [0, 0, 1, 0; 0, 0, 0, 1; 0, 0, 0, 0; 0, 0, 0, 0];
B = [0, 0; 0, 0; 1, 0; 0, 1];
Bw = B;
rho = 2.0; % Given value of rho

% Define YALMIP variables
X = sdpvar(4,4);         % Symmetric matrix variable X
Y = sdpvar(2,4);         % Rectangular matrix variable Y
lambda0 = sdpvar(1);     % Scalar variable lambda0
muu = sdpvar(1);         % Scalar variable muu
alpha_min = sdpvar(1);   % Variable for the smallest eigenvalue
% lambda = sdpvar(1);      % Variable for lambda
P = sdpvar(4,4);         % Auxiliary variable for P = X^(-1)

% Initialize constraints
Constraints = [X >= 1e-10 * eye(4)]; % Relax positive definiteness if needed
Constraints = [Constraints,  muu >= 0, alpha_min >= 0, lambda0 >= 10];

% Schur complement constraint to enforce P = X^(-1)
Constraints = [Constraints, [X, eye(4); eye(4), P] >= 0];

% Set alpha_min as the smallest eigenvalue of P
Constraints = [Constraints, P >= alpha_min * eye(4)];

% Main LMI condition
LMI = [ (A*X + B*Y)' + A*X + B*Y, Bw; 
        Bw', -muu * eye(2)];
Constraints = [Constraints, LMI <= -lambda0]; % Add LMI constraint

% Constraints = [Constraints, lambda - lambda0 <= 0]
% Add the new constraint based on the inequality
% Constraints = [Constraints, rho <= (lambda0 - lambda) * alpha_min / 2];

% Objective: Maximize lambda0 (changed to maximize lambda0, as we previously minimized -lambda0)
Objective = [];

% Solver settings
options = sdpsettings('solver', 'sdpt3', 'verbose', 1); % Verbose output for debugging

% Solve the problem
sol = optimize(Constraints, Objective, options);

% Check feasibility
if sol.problem == 0
    % Retrieve and display results
    X_opt = value(X);
    Y_opt = value(Y);
    lambda0_opt = value(lambda0);
    muu_opt = value(muu);
    alpha_min_opt = value(alpha_min);
    % lambda_opt = value(lambda);

    disp('Optimal values found:')
    disp('X = ')
    disp(X_opt)
    disp('Y = ')
    disp(Y_opt)
    disp(['lambda0 = ' num2str(lambda0_opt)])
    disp(['muu = ' num2str(muu_opt)])
    disp(['alpha_min (smallest eigenvalue of P) = ' num2str(alpha_min_opt)])
    % disp(['lambda = ' num2str(lambda_opt)])
else
    disp('The problem is infeasible. Adjust constraints or review model formulation.')
end
