function F = unblkdiag(F)

F = unblkdiag(lmi(F));