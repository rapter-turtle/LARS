function F = clean(X)

F = clean(lmi(X));
