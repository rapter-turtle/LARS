function v = depends(X)
% depends (overloaded)

v = depends(sdpvar(X));