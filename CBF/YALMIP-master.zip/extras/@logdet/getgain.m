function cx = getgain(X)

cx = X.gain;
