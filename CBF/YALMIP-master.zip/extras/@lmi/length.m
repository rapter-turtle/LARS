function varargout=length(varargin)

F = varargin{1};
varargout{1} = length(F.LMIid);
